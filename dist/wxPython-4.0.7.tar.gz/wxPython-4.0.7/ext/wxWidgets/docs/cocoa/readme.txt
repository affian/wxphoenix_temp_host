----------------------------------------------------------------------------
NB: This is the old wxCocoa port, you almost certainly want to read
    docs/osx/readme.txt for information about wxOSX/Cocoa instead.
----------------------------------------------------------------------------

Welcome to wxCocoa

wxCocoa is still very much a work in progress.  At this point quite a bit
of functionality is working, but quite a bit is left to do.  wxCocoa is not
yet suitable for a direct port of most wxWidgets applications. Fortunately,
wxMac is available for those looking to move to Mac today.

If you're still reading then I assume you're interested in helping with
the wxCocoa port.  Please join the wx-dev@lists.wxwindows.org mailing list
so we can talk!  There is plenty of work that can be done independently.
For example, many of the controls (listboxes, sliders, gauges, steppers,
etc.) can be easily worked on and the implementation should be pretty
straightforward (see how wxButton is wired up for an example of how to
handle events).

I welcome any help, but please shoot a message to wx-dev or to me
privately, dfe@cox.net, so there is no needless duplication of work.

Thanks a bunch!
David Elliott
